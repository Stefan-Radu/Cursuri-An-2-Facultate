#ifndef DISKANALYZER_ANALYZER_H
#define DISKANALYZER_ANALYZER_H

void analyze(const char*, int);

#endif //DISKANALYZER_ANALYZER_H
