#ifndef DISKANALYZER_DAEMON_FLOW_H
#define DISKANALYZER_DAEMON_FLOW_H

#include "../Shared/shared.h"

int run_daemon();

#endif //DISKANALYZER_DAEMON_FLOW_H
